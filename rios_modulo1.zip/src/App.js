
import './App.css';
import Ingreso from './compo_ingreso';
import Secreto from './compo_secret';
import Mail from './compo_mail';
import Telefono from './compo_tel';



function App() {
  return (
    
      <form>
        <div>
    <Ingreso dato="Nombre" />
        </div>    
    <Ingreso dato="Apellido" />
    <div>   
       <Mail dato="Email"/>    
    </div>
<div>  
  <Telefono dato ="Telefono"/>  
</div>
      <div>
    <Secreto dato="Password"/>
    </div>
    
    <div>    
    <Secreto dato="Confirmar Pass"/>
    </div>



    </form>
    

  );
}

export default App;
